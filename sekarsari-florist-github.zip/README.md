# Sekarsari Florist — Website Katalog

Website katalog florist dengan gaya soft luxury:
- Warm ivory / cream
- Dusty & blush pink
- Muted navy
- Responsive / mobile-first
- Katalog dengan filter kategori
- Tombol WhatsApp
- Instagram, TikTok, dan Google Maps

## 1. Sebelum dipublikasikan

Buka `index.html`, lalu ganti nomor WhatsApp:

`6281234567890`

dengan nomor WhatsApp Sekarsari Florist tanpa tanda `+`, spasi, atau angka 0 di depan.

Contoh:
`628xxxxxxxxxx`

Ganti juga link Instagram/TikTok dan alamat Google Maps jika diperlukan.

## 2. Mengganti foto

Foto saat ini menggunakan gambar contoh dari Unsplash agar website langsung terlihat saat dibuka.

Untuk memakai foto asli Sekarsari Florist:
1. Masukkan foto ke folder `assets/images/`
2. Pada `index.html`, ubah URL `https://images.unsplash.com/...` menjadi:
   `assets/images/nama-foto.jpg`

Contoh:
`<img src="assets/images/bunga-papan-1.jpg" alt="Bunga papan">`

## 3. Upload ke GitHub

Buat repository baru, misalnya:

`sekarsari-florist`

Upload:
- `index.html`
- folder `assets`
- `README.md`

Kemudian:
`Settings` → `Pages` → `Deploy from a branch` → pilih `main` → `/ (root)` → `Save`.

Beberapa saat kemudian website akan tersedia di:
`https://USERNAME.github.io/sekarsari-florist/`

## 4. Domain sendiri

Jika nanti ingin menggunakan domain `sekarsari.online`, domain tersebut dapat diarahkan ke GitHub Pages melalui pengaturan DNS dan file `CNAME`.

## Catatan

Harga produk pada contoh adalah placeholder dan sebaiknya disesuaikan sebelum website dipublikasikan.
